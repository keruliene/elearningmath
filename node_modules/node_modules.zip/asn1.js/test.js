'use strict';

const rfc5280 = require('./rfc/5280');

const tbs = 
