var ix = require('./');
ix.a.a();
ix.a.b();
ix.b.a();
ix.b.b();
