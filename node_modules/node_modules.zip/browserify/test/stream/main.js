t.equal(require('./foo.js'), 333);
t.equal(require('./bar.js'), 444);
