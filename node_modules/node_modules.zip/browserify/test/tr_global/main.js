console.log(require('x'));
