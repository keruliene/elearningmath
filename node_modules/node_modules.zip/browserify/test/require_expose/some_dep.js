module.exports = 'some_dep';
